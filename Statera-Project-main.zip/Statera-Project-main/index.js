'use strict';

/* BUTTONS */
const descubraBtn = document.querySelector('.btn--scroll-to');
const esportesBtn = document.querySelector('.nav__link-2');
const irParaForm = document.querySelector('.form__btn');
const inputParaForm = document.querySelector('.form__input');

/* SECTIONS */
const section1 = document.querySelector('#section--1');
const section2 = document.querySelector('#section--2');
const section3 = document.querySelector('#section--3');

/* BTNS SCROOL */
descubraBtn.addEventListener('click', function() {
    section2.scrollIntoView({ behavior: 'smooth' });
});

/* LINKS SCROLL */
document.querySelectorAll('.nav__link').forEach(function(el) {
    el.addEventListener('click', function(e) {
        e.preventDefault();

        const id = this.getAttribute('href');
        console.log(id);
        document.querySelector(id).scrollIntoView({ behavior: 'smooth' });
    });
});

/* MODALS */
const overlayCreatAccount = document.querySelector('.overlay');
const modalCreatAccount = document.querySelector('.modal');

esportesBtn.addEventListener('click', function() {
    section2.scrollIntoView({ behavior: 'smooth' });
});

/* FUNTION SHOW AND CLOSE CREAT ACCOUNT MODAL */

irParaForm.addEventListener('click', function(e) {
    if (inputParaForm.value !== '') {
        overlayCreatAccount.classList.remove('hidden');
        modalCreatAccount.classList.remove('hidden');
    }
});

overlayCreatAccount.addEventListener('click', function(e) {
    overlayCreatAccount.classList.add('hidden');
    modalCreatAccount.classList.add('hidden');
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !overlayCreatAccount.classList.contains('hidden')) {
        overlayCreatAccount.classList.add('hidden');
        modalCreatAccount.classList.add('hidden');
    }
});

function cadastro() {

    let cpf = document.getElementById("cpf");
    let name = document.getElementById("name");
    let email = document.getElementById("email");
    let senha = document.getElementById("senha");

    let dados = JSON.parse(localStorage.getItem("name"));

    if (dados == null) {

        localStorage.setItem("name", "[]");
        dados = [];

    }

    let auxRegistro = {

        cpf: cpf.value,
        nome: name.value,
        email: email.value,
        senha: senha.value

    };

    dados.push(auxRegistro);
    localStorage.setItem("name", JSON.stringify(dados));
    alert("Cadastro realizado com sucesso");
}

function enviar() {

    window.location.href = "landpage.html";

}

function pegar() {

    let nome = document.getElement("name");
    let senha = document.getElementById("senha");

    let recuperar = JSON.parse(localStorage.getItem("name"));

    if (recuperar != null) {

        localStorage.getItem("name", "[]");
        recuperar = [];
    }

    let auxRecuperar = {

        nome: apelido.value,
        senha: senha.value

    };

    recuperar.push(auxRecuperar);
    localStorage.getItem("name", JSON.stringify(recuperar));
}